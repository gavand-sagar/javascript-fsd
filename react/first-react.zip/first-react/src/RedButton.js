export default function RedButton({ label }) {
    return (<>
        <input></input><button>{label}</button>
    </>)
}